function fadeOutSVG() {
    // Ваш код для анимации или других действий перед переходом на другую страницу
    
    // Переход на другую страницу
    window.location = "http://domos.top/main.html"; // Замените "https://example.com" на URL страницы, на которую вы хотите перейти
  }