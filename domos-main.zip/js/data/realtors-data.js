export const realtors = [
    {
        name: 'Светлана',
        image: 'svetlana',
        type: 'Квартиры',
        country: 'Россия',
        region: 'Свердловская область',
        city: 'Екатеринбург',
        experience: 'До 5 лет',
        sex: 'Женский'
    },
    {
        name: 'Георгий',
        image: 'georgiy',
        type: 'Дома',
        country: 'Россия',
        region: 'Челябинская область',
        city: 'Челябинск',
        experience: 'От 5 лет',
        sex: 'Мужской'
    },
];