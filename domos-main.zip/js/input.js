function fadeOutSVG() {
    let svgContainer = document.querySelector('.svg-container');
    let svgElement = document.querySelector('.svg-container svg');
  
    svgElement.style.pointerEvents = 'none'; // Отключить кликабельность SVG-элемента
  
    svgElement.addEventListener('animationend', function () {
      // Удалить SVG-элемент после окончания анимации
      svgContainer.parentNode.removeChild(svgContainer);
    });
  }
  